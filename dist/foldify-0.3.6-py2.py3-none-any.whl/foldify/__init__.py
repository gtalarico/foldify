'Foldify - CLI tools for managing directory Trees.'

__author__ = 'gtalarico@gmail.com'
__version__ = '0.3.5'
