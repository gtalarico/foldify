'Foldify - CLI tools for managing directory Trees.'

__author__ = 'gtalarico@gmail.com'
__version__ = '0.3.4'

'''
Release Notes

3.2
Added empty dir label and tests.
'''
